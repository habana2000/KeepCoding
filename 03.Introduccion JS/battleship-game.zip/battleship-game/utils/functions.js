import {CHAR_OFFSET, BOARD_SIZE} from '../data/settings.js'

/**
 * It generates number between [min, max]
 * @param {Number} min 
 * @param {Number} max 
 * @returns {Number}
 */
export function generateRandomNumber(min = 0, max = BOARD_SIZE) {
    return Math.floor(Math.random() * (max + 1 - min) + min)
}
/**
 * Returns a random item from the array
 * @param {Array} arr 
 * @returns {Mixed}
 */
export const randomItem = arr => arr.splice((Math.random() * arr.length) | 0, 1);

/**
 * Utility function to convert 0 to A, 1 to B, etc
 * @param {Number} numericIndex 
 * @returns {String}
 */
export function getColumnIndex(numericIndex) {
    return String.fromCharCode(CHAR_OFFSET + numericIndex)
}

/**
 * 
 * @param {String} charCode 
 * @returns {Number}
 */
export function getNumericIndex(string) {
    return string.charCodeAt(0) - CHAR_OFFSET
}

/**
 * It converts a number to a coordinate
 * @param {Number} index 
 * @returns {Object}
 */
export const convertIndexToCoordinates = (index) => ({rowIndex: Math.floor(index / BOARD_SIZE) , columnIndex: getColumnIndex(index % BOARD_SIZE)})

/**
 * 
 * @param {Object} coordinate 
 * @returns {Number}
 */
export const convertCoordinateToIndex = (coordinate) => coordinate.rowIndex * BOARD_SIZE + getNumericIndex(coordinate.columnIndex)
