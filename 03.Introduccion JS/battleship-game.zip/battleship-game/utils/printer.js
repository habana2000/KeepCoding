export const usePrinter = function() {

    const printHeading = (text) => {
        const padd = '='.repeat(text.length)
        console.log(`==========${padd}==========`)
        console.log(`========= ${text} =========`)
        console.log(`==========${padd}==========`)
    }

    const printSectionHeading = (text) => {
        const padd = '='.repeat(text.length)
        console.log(``)
        console.log(`${text}`)
        console.log(`${padd}`)
    }

    const printNewLine = (...data) => {
        console.log(...data)
    }

    const printBoards = (player, onlyOwn = false, boardName = 'myBoard') => {
        printNewLine(`Own board: `)
        console.table(player[boardName])
        if (!onlyOwn) {
            printNewLine(`Enemy board: `)
            console.table(player.enemyBoard)
        }
        
    }
    
    return {
        printHeading,
        printNewLine,
        printSectionHeading,
        printBoards
    }
}