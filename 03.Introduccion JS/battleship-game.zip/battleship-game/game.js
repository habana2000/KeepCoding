import { AVAILABLE_SHIPS, EMPTY_CELL, HIT_CELL, PLAYERS, WATER_CELL, MAX_SHOOTS, SMART_MODE } from "./data/settings.js"
import { generatePlayer } from "./player.js"

/**
 * 
 */
export default {
    players: [],
    availableShips: AVAILABLE_SHIPS.map(ship => ({ ...ship, coordinates: [] })),
    rounds: [],
    winner: undefined,
    smartMode: SMART_MODE,
    /**
     * it generates the players and sets them up
     */
    setupGame() {
        if (PLAYERS !== 2) {
            throw new Error('Sorry, only 2 players are allowed 🆘')
        }
        for (let i = 0; i < PLAYERS; i++) {
            this.players.push(generatePlayer(i))
        }

        this.players.forEach(player => player.setupPlayer(this.availableShips))
    },
    /**
     * it plays the game
     */
    start() {
        // While there's no winner
        let playerIndex = 0
        let roundIndex = 0
        while (!this.winner && this.stillShootsRemaining()) {
            // Setup players turn
            const player = this.players[playerIndex]
            const enemyPlayer = this.players[(playerIndex + 1 )% 2]
            
            // register the round
            const round = {
                roundIndex,
                playerName: player.playerName,
                shoots: []
            }
            // while there still are enemy ships 
            while (player.enemyShipsCells > 0 && player.shootsDone < MAX_SHOOTS) {
                // player: select a coordinate of enemy'sBoard
                const coordinate = player.getEnemyCoordinate(this.smartMode)
                // register the shoot
                const shoot = {
                    shootNumber: player.shootsDone,
                    coordinate,
                    myBoard: undefined,
                    enemyBoard: undefined,
                    hitType: undefined,
                    drawn: false
                }
                round.shoots.push(shoot)
                // Check enemy's player
                if (enemyPlayer.getCellStatus(coordinate) === EMPTY_CELL) {
                    // update the boards
                    this.updatePlayersBoards(player, enemyPlayer, coordinate, WATER_CELL)
                    // register the board after this shoot
                    this.registerShoot(shoot, player, WATER_CELL)
                    // stop playing with this player
                    break
                } else if (
                    enemyPlayer.getCellStatus(coordinate) === HIT_CELL ||
                    enemyPlayer.getCellStatus(coordinate) === WATER_CELL
                ) {
                    throw new Error('Trying to shoot on a cell that is already taken')
                    // Hit!
                } else {
                    // update there are 1 less cell to discover
                    player.enemyShipsCells--
                    // update the boards
                    this.updatePlayersBoards(player, enemyPlayer, coordinate, HIT_CELL)
                    this.registerShoot(shoot, player, HIT_CELL)
                    // if drawn
                    shoot.drawn = this.isShipDrawn(enemyPlayer, coordinate)
                    // check if we finished
                    if (player.enemyShipsCells === 0) {
                        this.winner = player
                        break
                    }
                }
            }
            // register the round
            this.rounds.push(round)
            playerIndex = (playerIndex + 1) % 2
            // update round only when the next playerIndex is the first one
            playerIndex === 0 && roundIndex++
        }
        if (!this.winner) {
            this.resolveDraw()
        }
    },
    /**
     * It updates the cell status 
     * @param {Object} playerA 
     * @param {Object} playerB 
     * @param {Object} coordinate 
     * @param {String} hitType 
     */
    updatePlayersBoards(playerA, playerB, coordinate, hitType = WATER_CELL) {
        playerA.updateBoardCell('enemyBoard', coordinate, hitType)
        playerB.updateBoardCell('myBoard', coordinate, hitType)
    },
    /**
     * It registers the boards at the time of the shoot to a log called shoot
     * @param {Object} shoot 
     * @param {Object} player 
     * @param {String} hitType 
     */
    registerShoot(shoot, player, hitType = WATER_CELL) {
        shoot.myBoard = player.myBoard.map(col => ({...col}))
        shoot.enemyBoard = player.enemyBoard.map(col => ({...col}))
        shoot.hitType = hitType
    },
    /**
     * It checks if a ship placed in coordinate is drawn
     * @param {Object} player 
     * @param {Object} coordinate 
     * @returns 
     */
    isShipDrawn(player, coordinate) {
        const shipThatHasBeenHit = player.ships.find(ship => 
            ship.coordinates.find(coord => coord.rowIndex === coordinate.rowIndex && coord.columnIndex === coordinate.columnIndex)
        )

        return shipThatHasBeenHit.coordinates.every(coordinate => player.getCellStatus(coordinate) === HIT_CELL)
    },
    /**
     * It looks to any player that still has shoots
     * @returns {Boolean}
     */
    stillShootsRemaining(){
        return this.players.some(player => player.shootsDone < MAX_SHOOTS)
    },
    /**
     * It resolves the draw by looking at each player's enemyShipsCells property
     */
    resolveDraw(){
        const enemyShipsCellsArr = this.players.map(player => ({playerName: player.playerName, enemyShipsCells: player.enemyShipsCells}))
        enemyShipsCellsArr.sort((a,b) => a.enemyShipsCells - b.enemyShipsCells)
        if (enemyShipsCellsArr[0].enemyShipsCells !== enemyShipsCellsArr[1].enemyShipsCells) {
            this.winner = this.players.find(player => player.playerName === enemyShipsCellsArr[0].playerName)
        }
    }

}