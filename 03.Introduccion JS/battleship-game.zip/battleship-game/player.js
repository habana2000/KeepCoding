import { generateBoard, placeShipsOnBoard } from "./board.js";
import { CHAR_OFFSET, EMPTY_CELL, HIT_CELL, BOARD_SIZE, SMART_MODE } from "./data/settings.js";
import {
    randomItem,
    getColumnIndex,
    getNumericIndex,
    convertIndexToCoordinates,
    convertCoordinateToIndex,
} from "./utils/functions.js";

/**
 * It generates a new player, with the following props:
 * myBoard: {Array[]}
 * enemyBoard: {Array[]}
 * setupPlayer: {Function}
 * @returns {Object}
 */
export function generatePlayer(playerIndex = 0) {
    return {
        playerName: String.fromCharCode(CHAR_OFFSET + playerIndex),
        myBoard: generateBoard(),
        enemyBoard: generateBoard(),
        shootsDone: 0,
        enemyShipsCells: 0,
        enemyBoardAvailableCells: [],
        enemyBoardCandidateCells: [],
        ships: [],
        // coordinatesUsed: [],
        /**
         * It sets up a player, placing the available ships on its board
         * @param {Object[]} availableShips
         */
        setupPlayer(availableShips) {
            placeShipsOnBoard(availableShips, this.myBoard, this.ships);
            this.enemyShipsCells = availableShips.reduce((prev, next) => (prev += next.size), 0);
            this.enemyBoardAvailableCells = [...Array(this.enemyBoard.length * this.enemyBoard.length).keys()];
            this.originalBoard = this.myBoard.map(e => ({...e}))
        },
        /**
         * It updates the shootsDone and returns the coordinate like: {rowIndex: 3, columnIndex: 'B'} by prioritizing the candidates
         * @param {Boolean} smartMode 
         * @returns {Object}
         */
        getEnemyCoordinate(smartMode = true) {
            this.shootsDone++;
            if (smartMode && this.enemyBoardCandidateCells.length > 0) {
                // 💡could be improved here by recording the direction and the last shot, or sorting by preference given this params
                const coordinate = this.enemyBoardCandidateCells.pop();
                // remove from availableCells
                const indexFromCoordinate = convertCoordinateToIndex(coordinate);
                this.enemyBoardAvailableCells = this.enemyBoardAvailableCells.filter(
                    (cell) => cell !== indexFromCoordinate
                );
                return coordinate;
            } else {
                const randomIndex = randomItem(this.enemyBoardAvailableCells);
                return convertIndexToCoordinates(randomIndex);
            }
        },
        /**
         * 
         * @param {String} board 
         * @param {Object} coordinate 
         * @param {String} hitType 
         */
        updateBoardCell(board, coordinate, hitType) {
            this[board][coordinate.rowIndex][coordinate.columnIndex] = hitType
            if (hitType === HIT_CELL && board === 'enemyBoard') {
                this.updateEnemyBoardCandidateCells(coordinate)
            }
        },
        /**
         * It returns the cell status of player's board
         * @param {Object} coordinate
         * @returns {String}
         */
        getCellStatus(coordinate, board = this.myBoard) {
            return board[coordinate.rowIndex][coordinate.columnIndex];
        },
        /**
         * It generates the possible candidates from a cell, being top, right, bottom, left whenever they exist in the board and are still not shoot
         * @param {Object} coordinate
         * @returns {Object[]}
         */
        generateCandidates(coordinate) {
            const crossCandidates = [
                {
                    rowIndex: coordinate.rowIndex - 1,
                    columnValue: getNumericIndex(coordinate.columnIndex),
                    columnIndex: getColumnIndex(getNumericIndex(coordinate.columnIndex)),
                }, // top
                {
                    rowIndex: coordinate.rowIndex,
                    columnValue: getNumericIndex(coordinate.columnIndex) + 1,
                    columnIndex: getColumnIndex(getNumericIndex(coordinate.columnIndex) + 1),
                }, // right
                {
                    rowIndex: coordinate.rowIndex + 1,
                    columnValue: getNumericIndex(coordinate.columnIndex),
                    columnIndex: getColumnIndex(getNumericIndex(coordinate.columnIndex)),
                }, // bottom
                {
                    rowIndex: coordinate.rowIndex,
                    columnValue: getNumericIndex(coordinate.columnIndex) - 1,
                    columnIndex: getColumnIndex(getNumericIndex(coordinate.columnIndex) - 1),
                }, // left
            ];
            return crossCandidates.filter(
                (candidate) =>
                    candidate.rowIndex >= 0 &&
                    candidate.rowIndex < BOARD_SIZE && // check rows limit
                    candidate.columnValue >= 0 &&
                    candidate.columnValue < BOARD_SIZE && // check cols limit
                    this.getCellStatus(candidate, this.enemyBoard) === EMPTY_CELL // check cell status
            );
        },
        /**
         * It updates the list of coordinates from the generated candidate cells
         * @param {Object} coordinate
         */
        updateEnemyBoardCandidateCells(coordinate) {
            const listOfCoordinates = this.generateCandidates(coordinate);
            // they must be unique to be pushed: if C0 and E0 have a boat, both will produce D0 as a candidate
            listOfCoordinates.forEach((candidate) => {
                const found = this.enemyBoardCandidateCells.find(
                    (alreadyCandidateCoord) =>
                        alreadyCandidateCoord.rowIndex === candidate.rowIndex &&
                        alreadyCandidateCoord.columnIndex === candidate.columnIndex
                );
                if (!found) {
                    this.enemyBoardCandidateCells.push(candidate);
                }
            });
        }
    };
}
