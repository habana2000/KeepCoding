import { BOARD_SIZE, EMPTY_CELL } from "./data/settings.js"
import { generateRandomNumber, getColumnIndex } from "./utils/functions.js"

/**
 * It generates an empty board. A board is a 2D Matrix
 * @param {Number} size 
 * @returns {Object[]}
 */
export function generateBoard(size = BOARD_SIZE) {
    const board = []
    for (let i = 0; i < size; i++) {
        board[i] = []
        for (let j = 0; j < size; j++) {
            const index = getColumnIndex(j)
            board[i][index] = EMPTY_CELL
            // board[i][j] = EMPTY_CELL
        }
    }
    return board
}

/**
 * It places the list of ships on the board and updates the playerShips
 * @param {Object[]} ships 
 * @param {Array[]} board 
 * @param {Object[]} playerShips
 */
export function placeShipsOnBoard(ships, board, playerShips) {
    ships.forEach(ship => {
        const coordinates = placeShipOnBoard(ship, board)
        playerShips.push({...ship, coordinates})
    })
}

/**
 * It places one ship on the board
 * @param {Object} ship 
 * @param {Array[]} board 
 * @returns {Object[]}
 */
function placeShipOnBoard(ship, board) {
    while (true) {
        // set params for a correct placement (be aware of the col and row maximums)
        const settingsPlacement = {
            horizontal: generateRandomNumber(0, 1),
            columnIndex: generateRandomNumber(0, BOARD_SIZE - ship.size - 1),
            rowIndex: generateRandomNumber(0, BOARD_SIZE - ship.size - 1)
        }

        // check if the ship can be placed, otherwise keep trying with new settings
        if (canBePlaced(ship, settingsPlacement, board)) {
            // register the ship
            return registerShipOnBoard(ship, settingsPlacement, board)
        }
    }
}
/**
 * It checks if the ship, according to the placement, can be placed on the board
 * @param {Object} settingsPlacement 
 * @param {Array[]} board 
 * @returns {Boolean}
 */
function canBePlaced(ship, settingsPlacement, board) {
    let flagCanBePlaced = true
    const {maxColumnIndex, maxRowIndex} = getMaximumsColAndRow(ship, settingsPlacement)
    for (let i = settingsPlacement.columnIndex; i < maxColumnIndex; i++) {
        for (let j = settingsPlacement.rowIndex; j < maxRowIndex; j++) {
            const index = getColumnIndex(j)
            flagCanBePlaced &= board[i][index] === EMPTY_CELL
        }
    }
    return flagCanBePlaced
}
/**
 * It places the ship on the board according to the placement and returns the coordinates for the ship
 * @param {Object} settingsPlacement 
 * @param {Array[]} board 
 * @returns {Object[]}
 */
function registerShipOnBoard(ship, settingsPlacement, board) {
    const coordinates = []
    const {maxColumnIndex, maxRowIndex} = getMaximumsColAndRow(ship, settingsPlacement)
    for (let i = settingsPlacement.columnIndex; i < maxColumnIndex; i++) {
        for (let j = settingsPlacement.rowIndex; j < maxRowIndex; j++) {
            const index = getColumnIndex(j)
            board[i][index] = ship.icon
            coordinates.push({
                rowIndex: i,
                columnIndex: index
            })
        }
    }
    return coordinates
}
/**
 * It computes the minimum and maximum positions of the col and row index according to the placement
 * @param {Object} settingsPlacement 
 * @param {Array[]} board 
 * @returns {Object}
 */
function getMaximumsColAndRow(ship, settingsPlacement) {
    const maxColumnIndex = settingsPlacement.columnIndex + (settingsPlacement.horizontal ? 1 : ship.size)
    const maxRowIndex = settingsPlacement.rowIndex + (settingsPlacement.horizontal ? ship.size : 1)
    return {maxColumnIndex, maxRowIndex} 
}

