import { getColumnIndex } from './utils/functions.js'
import { usePrinter } from './utils/printer.js'
const { printHeading, printNewLine, printBoards, printSectionHeading } = usePrinter()

export default function showBattleshipGame(battleShipGame) {

    // [DONE] El programa empieza con una frase indicando que empieza el juego (el idioma no importa) 
    printHeading('The Battleship simulator starts')

    // [DONE] El programa deberá mostrar la colocación de las naves en el tablero propio del Jugador 1 y a continuación mostrar las naves del tablero propio del Jugador 2
    battleShipGame.players.forEach((player, index) => {
        printNewLine(`Player ${getColumnIndex(index)}`)
        printBoards(player, true, 'originalBoard')
    })

    // [DONE] El programa deberá mostrar una frase indicando que empiezan las rondas
    printHeading('The game starts')

    // [DONE] Para cada turno, deberá mostrarse claramente el turno del jugador X y los disparos que faltan
    battleShipGame.rounds.forEach((round, i) => {
        // if (round.roundIndex > 2 && battleShipGame.rounds.length -1 !== i) return
        printSectionHeading(`Round ${round.roundIndex} for ${round.playerName}`)
        round.shoots.forEach(shoot => {
            // [DONE] Para cada disparo, se deberá mostrar la casilla seleccionada, los disparos que faltan del jugador, 
            // y los tableros del jugador que está disparando (el propio y el ajeno) con la casilla ya marcada, sea agua o tocado.
            let line = `Shoot #${shoot.shootNumber} pointing to ${shoot.coordinate.rowIndex}${shoot.coordinate.columnIndex}: ${shoot.hitType}`
            if (shoot.drawn) {
                line += ` and drawn!`
            }
            printNewLine(line)
            printBoards(shoot)
        })
    })

    // [DONE] Cuando termine la partida, deberá mostrarse por pantalla qué jugador ha ganado. 
    printNewLine()
    printNewLine()
    printNewLine('And the winner is.....')
    if (battleShipGame.winner) {
        printHeading(`Player ${battleShipGame.winner.playerName}`)
    } else {
        printHeading(`Nobody! 😲 there is a draw`)
    }
    printNewLine('And the final boards are')
    // [DONE] Deberá mostrarse también por pantalla el tablero propio del jugador 1 y el tablero propio del jugador 2, para poder visualizar los barcos que han quedado sin hundir
    battleShipGame.players.forEach((player, index) => {
        printNewLine(`Player ${getColumnIndex(index)}`)
        printNewLine(`Remaining enemy cells to be shoot: ${player.enemyShipsCells}`)
        printBoards(player, true)
    })
}