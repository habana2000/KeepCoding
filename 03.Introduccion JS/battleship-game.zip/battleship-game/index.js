// [DONE] El programa debe tener un index.js que será lo que ejecutaré
import battleShipGame from './game.js'
import showBattleshipGame from './showGame.js'

battleShipGame.setupGame()
battleShipGame.start()

showBattleshipGame(battleShipGame)