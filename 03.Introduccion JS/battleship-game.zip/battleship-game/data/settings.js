import { AIRCRAFT_CARRIER, BOAT, CRUISE, SUBMARINE, VESSEL } from "./ships.js"

export const PLAYERS = 2
export const BOARD_SIZE = 10
export const MAX_SHOOTS = 65

export const SMART_MODE = true

// [DONE] Las casillas deben tener los siguientes posibles representaciones (podéis usar cualquier representación que queráis siempre y cuando sean diferentes entre sí): 
// vacío
// agua
// barco
// tocado
export const EMPTY_CELL = '  '
export const BOAT_CELL = '⛵︎'
export const HIT_CELL = '💥'
export const WATER_CELL = '💧'

export const CHAR_OFFSET = 65

export const AVAILABLE_SHIPS = [
    AIRCRAFT_CARRIER,
    VESSEL,
    SUBMARINE,
    SUBMARINE,
    CRUISE,
    CRUISE,
    CRUISE,
    BOAT,
    BOAT,
    BOAT
]