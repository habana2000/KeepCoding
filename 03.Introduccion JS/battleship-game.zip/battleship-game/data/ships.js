export const AIRCRAFT_CARRIER = {name: 'aircraft carrier', size: 5, icon: '🛳️'}
export const VESSEL = {name: 'vessel', size: 4, icon: '🚢'}
export const SUBMARINE = {name: 'submarine', size: 3, icon: '⛴️'}
export const CRUISE = {name: 'cruise', size: 2, icon: '🛥️'}
export const BOAT = {name: 'boat', size: 1, icon: '⛵︎'}