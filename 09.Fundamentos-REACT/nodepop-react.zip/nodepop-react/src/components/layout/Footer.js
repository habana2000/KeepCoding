function Footer() {
  return <footer>@Keepcoding 2021</footer>;
}

export default Footer;
