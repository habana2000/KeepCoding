export { default } from './NewAdvertPage';
